<?php

  class ScriptsJournaux{

    private $connexions = "sudo cat /var/log/apache2/access.log > /var/www/html/php/documents/access_log.txt";
    private $erreurs = "sudo cat /var/log/apache2/error.log > /var/www/html/php/documents/errors_log.txt";
    private $modsecurity = "sudo cat /var/log/apache2/modsec_audit.log > /var/www/html/php/documents/modsecurity_log.txt";

    public function __construct(){

    }

    public function getConnexions(){
      return $this->connexions;
    }

    public function getErreurs(){
      return $this->erreurs;
    }

    public function scriptConnexions(){
      echo shell_exec($this->getConnexions());
    }

    public function scriptErreurs(){
      echo shell_exec($this->getErreurs());
    }



  }

?>
