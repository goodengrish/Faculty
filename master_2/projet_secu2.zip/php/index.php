<?php

  if (isset($_POST['interrogerBase'])){
    header('Location: interrogerBase.php');
  }

  else if (isset($_POST['visualisationJournaux'])){
    header('Location: visualisationJournaux.php');
  }

?>
<!DOCTYPE html>

  <head>
    <meta charset="UTF-8">
    <title>Accueil</title>
    <link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  </head>

  <body>
    <div class="container">

      <div class="row">
        <div class="col">
          <h1 class="banniere">Accueil</h1>
        </div>
      </div>

      <hr>

      <div class="row">
        <div class="col-sm-4">
          <form method="post" action="index.php">
            <div class="form-group">
              <input type="submit" class="btn btn-dark" name="interrogerBase" value="Interroger la base de données" />
            </div>
        </div>
      </div>

      <div class="row">
        <div class="col-sm-4">
          <form method="post" action="index.php">
            <div class="form-group">
              <input type="submit" class="btn btn-dark" name="visualisationJournaux" value="Visualiser les journaux du serveur Apache" />
            </div>
        </div>
      </div>

    </div>
  </body>

  <footer>
    <script src="bootstrap4/js/bootstrap.min.js"></script>
  </footer>

</html>
