<?php

?>
<!DOCTYPE html>

	<head>
		<meta charset="UTF-8">
		<title>Injection SQL</title>
	</head>

	<body>
		<h1>Une injection SQL a été détectée !</h1>
	</body>

</html>
