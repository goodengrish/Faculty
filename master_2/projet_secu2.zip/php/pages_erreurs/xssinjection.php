<?php

?>
<!DOCTYPE html>

	<head>
		<meta charset="UTF-8">
		<title>Injection XSS</title>
	</head>

	<body>
		<h1>Une injection XSS a été détectée !</h1>
	</body>

</html>
