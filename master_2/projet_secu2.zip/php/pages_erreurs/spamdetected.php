<?php

?>
<!DOCTYPE html>

	<head>
		<meta charset="UTF-8">
		<title>Détection de spam</title>
	</head>

	<body>
		<h1>Un mot-clé de spam a été détecté !</h1>
	</body>

</html>
