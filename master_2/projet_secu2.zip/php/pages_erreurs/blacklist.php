<?php

?>
<!DOCTYPE html>

	<head>
		<meta charset="UTF-8">
		<title>Mot blacklisté</title>
	</head>

	<body>
		<h1>Un mot blacklisté a été détecté</h1>
	</body>

</html>
