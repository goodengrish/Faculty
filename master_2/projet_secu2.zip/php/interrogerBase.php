<?php

  include 'operationsBase.php';

  $obj = new OperationsBase();

  // On affiche les erreurs php sur la page web, exceptée les notices
  error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);

  if (isset($_POST['valider'])){
    $obj->recuperationRequeteSQL($_POST['requeteSQLForm']);
  }

  if (isset($_POST['retourAccueil'])){
    header('Location: index.php');
  }

?>
<!DOCTYPE html>

  <head>
    <meta charset="UTF-8">
    <title>
      Interrogation de la base de données
    </title>
    <link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  </head>

  <body>
    <div class="container">

      <div class="row">
        <div class="col">
          <h1 class="banniere">Interrogation de la base de données</h1>
        </div>
      </div>

      <hr>

      <div class="row">

        <div class="col-sm-4">
          <form method="post" action="interrogerBase.php">
            <div class="form-group">
              <label for="requeteSQLForm">Votre requête SQL</label>
              <textarea class="form-control" name="requeteSQLForm" id="requeteSQL"></textarea>
              <br>
              <input type="submit" class="btn btn-dark" name="valider" value="Valider"></input>
            </div>
          </form>
        </div>

        <div class="col-sm-2"></div>

        <div class="col-sm-4">
          <h4 class="banniere">Tables et colonnes de la base de données</h4>

          <?php
            $obj->affichageTables();
          ?>
          <ul class="list-group">
            <?php
              $obj->affichageNomColonnes();
            ?>
          </ul>

        </div>

      </div>

      <br>

      <div class="row">
        <label for="resultatRequeteSQL">Le résultat de votre requête SQL</label>
        <textarea class="form-control" id="resultatRequeteSQL">
          <?php
            if ($obj->getResultatRequete() != ''){
              echo $obj->getResultatRequete();
            }
          ?>
      </textarea>
      </div>

      <div class="row">
        <?php
          if ($obj->getRequeteInvalide() != ''){
            echo $obj->getRequeteInvalide();
          }
        ?>
      </div>

      <br>

      <div class="row">
        <div class="col-sm-4">
          <form method="post" action="interrogerBase.php">
            <div class="form-group">
              <input type="submit" class="btn btn-dark" name="retourAccueil" value="Retour accueil" />
            </div>
          </form>
        </div>
      </div>

    </div>

  </body>

  <footer>
    <script src="bootstrap4/js/bootstrap.min.js"></script>
  </footer>

</html>
