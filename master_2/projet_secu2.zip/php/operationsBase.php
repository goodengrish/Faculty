<?php

class OperationsBase{

  private $chemin;
  private $interfacePDO;
  private $resultatRequete = '';
  private $requeteInvalide = '';

  // Liste des requêtes
  const LISTAGE_TABLES = "SELECT name FROM sqlite_master WHERE type='table';";
  const COLONNES_TABLES = "PRAGMA table_info(ROMAN)";
  const INSERTION_TABLE_ARTICLE = "INSERT INTO ARTICLE(AUTHOR,TITLE,PAGES,YEAR,VOLUME,JOURNAL,NUMBER,URL,EE) VALUES(?,?,?,?,?,?,?,?,?)";
  const INSERTION_TABLE_PHDTHESIS = "";

  public function __construct(){
    $this->chemin = 'sqlite:base/base.db';

    try{
      $this->interfacePDO = new PDO($this->chemin);
      $this->interfacePDO->setAttribute(PDO::ATTR_EMULATE_PREPARES,false);
      $this->interfacePDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    catch (PDOException $e){
      echo 'Connexion à la base de données échouée: '.$e->getMessage();
    }
  }

  public function getResultatRequete(){
    return $this->resultatRequete;
  }

  public function getRequeteInvalide(){
    return $this->requeteInvalide;
  }

  public function fermetureConnectionBase(){
    $this->interfacePDO = null;
  }

  public function affichageTables(){
    foreach($this->interfacePDO->query(self::LISTAGE_TABLES) as $table){
      if (strcmp($table['name'],'sqlite_sequence') !== 0){
        echo '<h6 class="banniere">'.$table['name'].'</h6>';
      }
    }
  }

  public function affichageNomColonnes(){
    foreach($this->interfacePDO->query(self::COLONNES_TABLES) as $col){
      echo '<li class="list-group-item">'.'Nom: '.$col[1].' | Type: '.$col[2].'</li>';
    }
  }

  /*
    Méthode de gestion de requêtes SQL
  */
  public function recuperationRequeteSQL($requete){
    if (empty($requete)){
      return $this->requeteInvalide = '
        <div class="alert alert-warning" role="alert">
          La requête saisie est vide.
        </div>
      ';
    }

    try{
        $stmt = $this->interfacePDO->prepare($requete);
    }
    catch (PDOException $exp){
      return $this->requeteInvalide = '
        <div class="alert alert-danger" role="alert">
          La requête saisie est invalide.
        </div>';
    }

    $this->requeteInvalide = '';
    $stmt->execute();
    $result = $stmt->fetchAll();

    foreach($result as $ligne){
      for($i = 0; $i < sizeof($ligne); $i += 1){
        $this->resultatRequete .= $ligne[$i]." - ";
      }
      $this->resultatRequete .= "\n";
    }
  }

}

?>
