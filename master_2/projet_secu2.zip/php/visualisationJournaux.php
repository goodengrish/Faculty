<?php

  include 'scriptsJournaux.php';

  $obj = new ScriptsJournaux();

  if (isset($_POST[retourAccueil])){
    header('Location: index.php');
  }

?>
<!DOCTYPE html>

  <head>
    <meta charset="UTF-8">
    <title>Visualisation des journaux du serveur Apache</title>
    <link rel="stylesheet" type="text/css" href="bootstrap4/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style/style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  </head>

  <body>

    <div class="container">

      <div class="row">
        <div class="col">
          <h1 class="banniere">Visualisation des journaux du serveur Apache</h1>
        </div>
      </div>

      <hr>

      <div class="row">

        <div class="col-sm-4">
          <h4 class="banniere">Connexions sur le serveur</h4>
          <pre>
            <?php
              $obj->scriptConnexions();
            ?>
          </pre>
        </div>

        <div class="col-sm-2"></div>

        <div class="col-sm-4">
          <h4 class="banniere">Erreurs liées au serveur</h4>
          <pre>
            <?php
              $obj->scriptErreurs();
            ?>
          </pre>
        </div>

      </div>

      <div class="row">
        <div class="col-sm-4">
          <form method="post" action="visualisationJournaux.php">
            <div class="form-group">
              <input type="submit" class="btn btn-dark" name="retourAccueil" value="Retour accueil" />
            </div>
          </form>
        </div>
      </div>

    </div>

  </body>

  <footer>
    <script src="bootstrap4/js/bootstrap.min.js"></script>
  </footer>

</html>
