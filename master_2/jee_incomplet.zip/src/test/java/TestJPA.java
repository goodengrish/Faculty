/**
 * 
 */
package fr.jvblaster.jpa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author Cloud-Strife
 *
 */
public class TestJPA {

    private final static String URL = "jdbc:postgresql://localhost:5432/dbatompunch";
    private final static String USER = "postgres";
    private final static String PASSW = "password";

    public static void main(String [] args) {
        Connection c = null;  
        try {    
            Class.forName("org.postgresql.Driver");
            System.out.println("Driver found");
            System.out.println("Connecting..."); 
            c = DriverManager.getConnection(URL, USER, PASSW);
            System.out.println(c.getCatalog());
        } catch (Exception e) {    
            System.out.println("Cannot connect the database"); 
            e.printStackTrace();
        } finally {    
            if (c != null) {       
                try {
					c.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}        
            }    
        }    
    }            
}    