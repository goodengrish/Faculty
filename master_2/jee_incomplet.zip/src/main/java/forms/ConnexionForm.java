package forms;

import beans.Utilisateur;

import javax.servlet.http.HttpServletRequest;

public class ConnexionForm {

    private static final String CHAMP_ID = "id";
    private static final String CHAMP_PSEUDO = "pseudo";
    private static final String CHAMP_MOTDEPASSE = "motdepasse";

    public Utilisateur connexionUtilisateur(HttpServletRequest request){

        //String id = getValeurChamp(request, CHAMP_ID);
        String pseudo = getValeurChamp(request, CHAMP_PSEUDO);
        String motdepasse = getValeurChamp(request, CHAMP_MOTDEPASSE);

        Utilisateur user = new Utilisateur();
        user.setId("1");
        user.setPseudo(pseudo);
        user.setMotdepasse(motdepasse);

        if (user.getPseudo() != null && user.getMotdepasse() != null){
            System.out.println("Connexion OK");
        }
        else{
            System.out.println("Connexion NOT OK");
        }

        return user;

    }

    private static String getValeurChamp(HttpServletRequest request, String nomChamp){
        String valeur = request.getParameter( nomChamp );
        if ( valeur == null || valeur.trim().length() == 0 ) {
            return null;
        } else {
            return valeur.trim();
        }
    }

}
