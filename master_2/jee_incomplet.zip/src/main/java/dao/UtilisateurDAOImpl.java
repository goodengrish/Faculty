package dao;

import beans.Utilisateur;
import exceptions.DAOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UtilisateurDAOImpl implements UtilisateurDAO{

    private DAOFactory daoFactory;
    private static final String RECUP_UTILISATEUR_PAR_PSEUDO = "SELECT ID, PSEUDO, MOTDEPASSE FROM UTILISATEUR WHERE PSEUDO = ?";
    private static final String INSERT_UTILISATEUR = "INSERT INTO UTILISATEUR(PSEUDO,MOTDEPASSE) VALUES(?,?)";

    UtilisateurDAOImpl(DAOFactory daoFactory){
        this.daoFactory = daoFactory;
    }

    public void create(Utilisateur utilisateur) throws DAOException {
        Connection connexion = null;
        PreparedStatement preparedStatement = null;
        ResultSet valeursAutoGenerees = null;

        try {
            /* Récupération d'une connexion depuis la Factory */
            connexion = daoFactory.getConnection();
            preparedStatement = DAOUtilitaire.initialisationRequetePreparee( connexion, INSERT_UTILISATEUR, true,utilisateur.getPseudo(), utilisateur.getMotdepasse());
            int statut = preparedStatement.executeUpdate();
            /* Analyse du statut retourné par la requête d'insertion */
            if ( statut == 0 ) {
                throw new DAOException( "Échec de la création de l'utilisateur, aucune ligne ajoutée dans la table." );
            }
            /* Récupération de l'id auto-généré par la requête d'insertion */
            valeursAutoGenerees = preparedStatement.getGeneratedKeys();
            if ( valeursAutoGenerees.next() ) {
                /* Puis initialisation de la propriété id du bean Utilisateur avec sa valeur */
                utilisateur.setId( valeursAutoGenerees.getLong( 1 ) );
            } else {
                throw new DAOException( "Échec de la création de l'utilisateur en base, aucun ID auto-généré retourné." );
            }
        } catch ( SQLException e ) {
            throw new DAOException( e );
        } finally {
            DAOUtilitaire.fermeturesSilencieuses( valeursAutoGenerees, preparedStatement, connexion );
        }
    }

    public Utilisateur read(String pseudo) throws IllegalArgumentException,DAOException {
        Connection connexion = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Utilisateur utilisateur = null;

        try {
            /* Récupération d'une connexion depuis la Factory */
            connexion = daoFactory.getConnection();
            preparedStatement = DAOUtilitaire.initialisationRequetePreparee( connexion, RECUP_UTILISATEUR_PAR_PSEUDO, false, pseudo);
            resultSet = preparedStatement.executeQuery();
            /* Parcours de la ligne de données de l'éventuel ResulSet retourné */
            if ( resultSet.next() ) {
                utilisateur = map( resultSet );
            }
        } catch ( SQLException e ) {
            throw new DAOException( e );
        } finally {
            DAOUtilitaire.fermeturesSilencieuses( resultSet, preparedStatement, connexion );
        }

        return utilisateur;
    }

    private static Utilisateur map(ResultSet resultSet) throws SQLException {
        Utilisateur utilisateur = new Utilisateur();

        utilisateur.setId(resultSet.getLong("ID"));
        utilisateur.setPseudo(resultSet.getString("PSEUDO"));
        utilisateur.setMotdepasse(resultSet.getString("MOTDEPASSE"));

        return utilisateur;
    }
}
