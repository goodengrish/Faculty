package dao;

import beans.Utilisateur;
import exceptions.DAOException;

public interface UtilisateurDAO {

    void create(Utilisateur utilisateur) throws DAOException;
    Utilisateur read(String pseudo) throws DAOException;

}
