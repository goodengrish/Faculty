package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnexionBase {

    private static String url = "jdbc:postgresql://localhost:5432/dbatompunch";
    private static Connection connect;
    private final static String USER = "postgres";
    private final static String PASSW = "password";

    public static Connection getInstance(){

        if (connect == null){
            try{
                Class.forName("org.postgresql.Driver");
                connect = DriverManager.getConnection(url,USER,PASSW);
            }
            catch (SQLException e){
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }
        System.out.println("connect est-il initialisé ?" + connect);
        return connect;
    }

}
