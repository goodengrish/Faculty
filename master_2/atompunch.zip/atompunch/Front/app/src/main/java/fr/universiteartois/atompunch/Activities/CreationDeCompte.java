package fr.universiteartois.atompunch.Activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.os.Bundle;

import fr.universiteartois.atompunch.R;

public class CreationDeCompte extends AppCompatActivity {

    private EditText pseudo;
    private EditText motdepasse;
    private Button validation;
    private Button retourPageConnexion;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_creation_compte);

        this.pseudo = findViewById(R.id.champPseudo);
        this.motdepasse = findViewById(R.id.champMotDePasse);
        this.validation = findViewById(R.id.validationChamps);
        this.retourPageConnexion = findViewById(R.id.retourPageConnexion);

        this.retourPageConnexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pageDeConnexionActivity = new Intent(CreationDeCompte.this, PageDeConnexion.class);
                startActivity(pageDeConnexionActivity);
            }
        });

    }

}
