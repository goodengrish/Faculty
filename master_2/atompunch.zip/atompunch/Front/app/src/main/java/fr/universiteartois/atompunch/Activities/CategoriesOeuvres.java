package fr.universiteartois.atompunch.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import fr.universiteartois.atompunch.R;

public class CategoriesOeuvres extends AppCompatActivity {

    private Button jeuxvideo;
    private Button cinema;
    private Button litt;
    private Button musique;
    private Button retourMenuPrincipal;

    // on trouvera comme valeur soit 'lire' soit 'ecrire'
    private String interet;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.categoriesoeuvres);

        /*Intent intentInteret = getIntent();
        interet = intentInteret.getStringExtra("interet");

        // on modifie le titre suivant le souhait de l'utilisateur (lire ou écrire)
        if (interet.equals("lire")){
            setTitle("Lire");
        }
        else{
            setTitle("Ecrire");
        }
*/
        this.retourMenuPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainActivity = new Intent(CategoriesOeuvres.this, MainActivity.class);
                startActivity(mainActivity);
            }
        });

    }

}
