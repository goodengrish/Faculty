package fr.universiteartois.atompunch.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import fr.universiteartois.atompunch.R;

public class MainActivity extends AppCompatActivity {

    private Button lire;
    private Button ecrire;
    private Button connexionDeconnexion;
    private Boolean estConnecte = false;

    public final static String lireName = "lire";
    public final static String ecrireName = "ecrire";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.lire = findViewById(R.id.boutonLire);
        this.ecrire = findViewById(R.id.boutonEcrire);
        this.connexionDeconnexion = findViewById(R.id.boutonConnexionDeconnexion);

        if (this.estConnecte == false){
            this.connexionDeconnexion.setText("Connexion");
        }
        else{
            this.connexionDeconnexion.setText("Déconnexion");
        }

        this.connexionDeconnexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pageDeConnexionActivity = new Intent(MainActivity.this, PageDeConnexion.class);
                startActivity(pageDeConnexionActivity);
            }
        });

        this.lire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent lireCategoriesActivity = new Intent(MainActivity.this, CategoriesOeuvres.class);
                lireCategoriesActivity.putExtra("interet", lireName);
                startActivity(lireCategoriesActivity);
            }
        });

        this.ecrire.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ecrireCategoriesActivity = new Intent(MainActivity.this, CategoriesOeuvres.class);
                ecrireCategoriesActivity.putExtra("interet", ecrireName);
                startActivity(ecrireCategoriesActivity);
            }
        });

    }



}
