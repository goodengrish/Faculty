package fr.universiteartois.atompunch.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import fr.universiteartois.atompunch.R;

public class PageDeConnexion extends AppCompatActivity {

    private EditText pseudo;
    private EditText motdepasse;
    private Button validation;
    private Button retourMenuPrincipal;
    private TextView nouveauCompte;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page_de_connexion);

        this.pseudo = findViewById(R.id.champPseudo);
        this.motdepasse = findViewById(R.id.champMotDePasse);
        this.validation = findViewById(R.id.validationChamps);
        this.nouveauCompte = findViewById(R.id.creationCompte);
        this.retourMenuPrincipal = findViewById(R.id.retourPagePrincipale);

        this.nouveauCompte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent creationDeCompteActivity = new Intent(PageDeConnexion.this, CreationDeCompte.class);
                startActivity(creationDeCompteActivity);
            }
        });

        this.retourMenuPrincipal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainActivity = new Intent(PageDeConnexion.this, MainActivity.class);
                startActivity(mainActivity);
            }
        });

    }

}
